/*
 * rx.c
 *
 *  Created on: Nov 19, 2019
 *      Author: katanbaf
 */

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include "RFQueue.h"
#include <ti_radio_config.h>
#include "board.h"

/***** Defines *****/
/* Packet RX Configuration */
#define DATA_ENTRY_HEADER_SIZE 8  /* Constant header size of a Generic Data Entry */
#define MAX_LENGTH             28 /* Max length byte the radio will accept */
#define NUM_DATA_ENTRIES       2  /* NOTE: Only two data entries supported at the moment */
#define NUM_APPENDED_BYTES     2  /* The Data Entries data field will contain:
                                   * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
                                   * Max 30 payload bytes
                                   * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) */

// Convert microseconds into RAT ticks.
#define RF_convertUsToRatTicks(microseconds)  ((uint32_t)(microseconds) * RF_RAT_TICKS_PER_US)

// Convert milliseconds into RAT ticks.
#define RF_convertMsToRatTicks(milliseconds)  RF_convertUsToRatTicks((milliseconds) * 1000)


/***** Prototypes *****/
static void rx_callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void rx_timeoutCb(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is 4 byte aligned (requirement from the RF Core) */
#if defined(__TI_COMPILER_VERSION__)
#pragma DATA_ALIGN (rxDataEntryBuffer, 4);
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__IAR_SYSTEMS_ICC__)
#pragma data_alignment = 4
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__GNUC__)
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)]
                                                  __attribute__((aligned(4)));
#else
#error This compiler is not supported.
#endif


//extern RF_Handle rfHandle;
//extern PIN_Handle ledPinHandle;
//extern UART_Handle uart;


/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;
static uint8_t packet[MAX_LENGTH + NUM_APPENDED_BYTES - 1]; /* The length byte is stored in a separate variable */
uint8_t end_packet[9] = {0x00, 0x55, 0xaa, '\n', '\r', 0x55, 0xaa, '\n', '\r'};
/***** Variable declarations *****/
static volatile bool bpacketReceived = false;
static volatile bool bPacketsLost = false;
static RF_CmdHandle rxCmdHndl = 0; // Handle needed to abort the RX command
static volatile RF_RatConfigCompare ratCompareConfig;
static volatile RF_RatHandle ratHandle = RF_ALLOC_ERROR;
static ratmr_t  currTimerVal = 0, rxTimeoutVal = 0;
static rfc_propRxOutput_t rxStat;
static int8_t intfr;

void init_rxQueue()
{
    if( RFQueue_defineQueue(&dataQueue,
                                rxDataEntryBuffer,
                                sizeof(rxDataEntryBuffer),
                                NUM_DATA_ENTRIES,
                                MAX_LENGTH + NUM_APPENDED_BYTES))
    {
        /* Failed to allocate space for all data entries */
        while(1);
    }
}

void init_rx()
{
    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRxAdv.pQueue = &dataQueue;
    RF_cmdPropRxAdv.rxConf.bAutoFlushIgnored = 0;
    RF_cmdPropRxAdv.rxConf.bAutoFlushCrcErr = 0;
    RF_cmdPropRxAdv.rxConf.bIncludeHdr = 0x1;
    RF_cmdPropRxAdv.rxConf.bIncludeCrc = 0x0;
    RF_cmdPropRxAdv.rxConf.bAppendRssi = 0x1;
    RF_cmdPropRxAdv.rxConf.bAppendTimestamp = 0x0;
    RF_cmdPropRxAdv.rxConf.bAppendStatus = 0x0;
    RF_cmdPropRxAdv.maxPktLen = MAX_LENGTH;
    RF_cmdPropRxAdv.pktConf.bRepeatOk = 1;
    RF_cmdPropRxAdv.pktConf.bRepeatNok = 1;
    RF_cmdPropRxAdv.pktConf.bFsOff = 0;
    RF_cmdPropRxAdv.pktConf.bCrcIncHdr = 0;
    RF_cmdPropRxAdv.pOutput = (uint8_t*)&rxStat;
    RF_cmdPropRxAdv.endTrigger.triggerType = TRIG_REL_START;

    /* Init RF_Rat */
    RF_RatConfigCompare_init((RF_RatConfigCompare *)&ratCompareConfig);
    ratCompareConfig.callback = (RF_RatCallback)&rx_timeoutCb;
    ratCompareConfig.channel  = RF_RatChannelAny;
}

void get_pkts(RF_Handle* rfHandle, UART_Handle* uart, PIN_Handle* ledPinHandle, uint16_t timeout)
//void get_pkts()
{
    uint8_t i;
    bpacketReceived = false;
    bPacketsLost = false;

    RF_cmdPropRxAdv.endTime = RF_convertMsToRatTicks(timeout);
    rxCmdHndl = RF_postCmd(*rfHandle, (RF_Op*)&RF_cmdPropRxAdv, RF_PriorityNormal, &rx_callback, RF_EventRxEntryDone);

    rxTimeoutVal = RF_convertMsToRatTicks(timeout);
    currTimerVal = RF_getCurrentTime();
    ratCompareConfig.timeout = currTimerVal + rxTimeoutVal;
    ratHandle = RF_ratCompare(*rfHandle, (RF_RatConfigCompare *)&ratCompareConfig, NULL);
    while(1)
    {
        if(bpacketReceived)
        {
            PIN_setOutputValue(*ledPinHandle, PIN_RLED, !PIN_getOutputValue(PIN_RLED));

            if(packetLength > MAX_LENGTH + NUM_APPENDED_BYTES - 1)
                packetLength = MAX_LENGTH + NUM_APPENDED_BYTES - 1;
            for (i=0; i<packetLength; ++i)
                packet[i] = packetDataPointer[i];
            packet[i++] = (uint8_t)intfr;
            packet[i++] = rxStat.lastRssi;
            packet[i++] = rxStat.nRxOk;
            packet[i++] = 0x55;
            packet[i++] = 0xaa;
            packet[i++] = '\n';
            packet[i++] = '\r';
            UART_write(*uart, packet, packetLength+7);
//            RF_cancelCmd(*rfHandle, rxCmdHndl, 0);
            rxStat.nRxOk = 0;
            bpacketReceived = false;
//            rxCmdHndl = RF_postCmd(*rfHandle, (RF_Op*)&RF_cmdPropRxAdv, RF_PriorityNormal, &rx_callback, RF_EventRxEntryDone);
        }
        else if(bPacketsLost)
        {
            RF_ratDisableChannel(*rfHandle, ratHandle);
//            RF_cancelCmd(*rfHandle, rxCmdHndl, 0);
            usleep(2000);
            UART_writeCancel(*uart);
            usleep(100);
            end_packet[0] = intfr;
            UART_write(*uart, end_packet, 9);
            break;
        }
    }
}

void rx_callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        /* Get current unhandled data entry */
        currentDataEntry = RFQueue_getDataEntry();

        RFQueue_nextEntry();

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t*)(&currentDataEntry->data);
        packetDataPointer = (uint8_t*)(&currentDataEntry->data + 1);

        /* Copy the payload + the status byte to the packet variable */  // Cause the CPU to Crash!!
//        memcpy(packet, packetDataPointer, (packetLength + 1));

        bpacketReceived = true;
    }
}

void rx_timeoutCb(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    bPacketsLost = true;
}

int32_t meas_interference(RF_Handle* rfHandle, uint8_t timeout, uint16_t readings, int16_t threshold)
{
    int32_t intfr_sum = 0;
    int16_t rssi;
//    int8_t intfr_array[readings];
    uint16_t i,j;
    RF_cmdRxTest.endTrigger.triggerType = TRIG_REL_START;
    RF_cmdRxTest.endTime = RF_convertMsToRatTicks(timeout);
    RF_postCmd(*rfHandle, (RF_Op*)&RF_cmdRxTest, RF_PriorityNormal, NULL, 0);

    j = 0;
    for (i=0; i<readings; i++)
    {
        rssi = RF_getRssi(*rfHandle);
//        intfr_array[i] = rssi;
        if (rssi > threshold)
        {
            intfr_sum += rssi;
            j++;
        }
    }

    intfr = intfr_sum / (j);
    return intfr;
}
