/*
 * Copyright (c) 2019, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include "RFQueue.h"
#include <ti_radio_config.h>
#include "rx.h"
#include "tx.h"
#include "board.h"

/***** Defines *****/
#define SYNC_FREQ 915


/***** Prototypes *****/
static void init_uart();
static void init_leds();
void init_radio();
void set_freq(uint16_t freq, uint16_t fractFreq);
void get_helper_freq(uint16_t bs_freq, uint16_t bs_fractFreq, sync_params* sync_data);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;

/* UART driver handle */
static UART_Handle uart;

extern uint8_t end_packet[9];
/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
PIN_Config pinTable[] =
{
    PIN_RLED     | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_GLED     | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_ANT_SEL  | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_BAND_SEL | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
	PIN_TERMINATE
};

/***** Function definitions *****/

void *mainThread(void *arg0)
{
    const char  start[] = "Start:\r\n";

    RF_Params rfParams;
    RF_Params_init(&rfParams);

    init_leds();
    init_uart();
    UART_write(uart, start, sizeof(start));

    init_rxQueue();
    init_radio();
    init_rx();
    init_tx();

    /* Request access to the radio */
#if defined(DeviceFamily_CC26X0R2)
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioSetup, &rfParams);
#else
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);
#endif// DeviceFamily_CC26X0R2

    PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
    PIN_setOutputValue(ledPinHandle, PIN_GLED, 0);
    PIN_setOutputValue(ledPinHandle, PIN_ANT_SEL, 1);
    PIN_setOutputValue(ledPinHandle, PIN_BAND_SEL, 1);

    uint16_t sync_freq = SYNC_FREQ;
    uint16_t sync_fractFreq = 0x0000;

    uint16_t bs_freq = 905;
    uint16_t bs_fractFreq = 0x0000;     //0: 0x00, 75k: 0x1334

    uint8_t timeout = 100;

    struct sync_params sync_data;
    sync_data.ver_seq = VER_SEQ;
    sync_data.helper_freq = bs_freq - 900;
    sync_data.helper_fractFreq = sync_fractFreq;
    sync_data.tx_id = 0;
    sync_data.tag_id = 0;
    sync_data.tx_ant = 1;
    sync_data.power = 5;
    sync_data.wake_up = 1;
    sync_data.timeout = timeout;
    sync_data.tag_cmd = 0xcc;

    uint8_t cmd[7] = {0,0,10,0,0,0,0};

    while(1)
    {
        PIN_setOutputValue(ledPinHandle, PIN_GLED, !PIN_getOutputValue(PIN_GLED));

        UART_read(uart, &cmd[0], sizeof(cmd));
        sync_data.tx_id = cmd[0];
        sync_data.tag_id = cmd[1];
        if(cmd[2] < 65)
        {
            bs_freq = 902 + (cmd[2]*4+2) / 10;
            bs_fractFreq = ((cmd[2]*4+2) % 10) * 0x1999;
            get_helper_freq(bs_freq, bs_fractFreq, &sync_data);
        }
        sync_data.tag_cmd = cmd[3];
        sync_data.timeout = cmd[4]; //2ms resolution
        if(cmd[5] <= TX_POWER_TABLE_SIZE - 1)
        {
            sync_data.power = cmd[5];
        }
//        sync_data.wake_up = (cmd[6] & 0x08) >> 3;
//        sync_data.tag_ant = (cmd[6] & 0x04) >> 2;
//        sync_data.tx_ant = (cmd[6] & 0x02) >> 1;
//        sync_data.rx_ant = (cmd[6] & 0x01);

        /*Carrier Sense*/
//        set_freq(bs_freq, bs_fractFreq);
//        int16_t intfr = meas_interference(&rfHandle, 2, 100, -110);
//        if (intfr > -80)
//        {
//            end_packet[0] = intfr + 128;
//            UART_write(uart, end_packet, 9);
//            continue;
//        }


        /*Send sync packet to helper*/
        set_freq(sync_freq, sync_fractFreq);
        send_sync_pkt(&rfHandle, sync_data);

//        /*Read RSSI during wakeup*/
        set_freq(900+sync_data.helper_freq, sync_data.helper_fractFreq);
        meas_interference(&rfHandle, 6, 400, -50);

        /*Receive incoming backscatter packets*/
        set_freq(bs_freq, bs_fractFreq);
        get_pkts(&rfHandle, &uart, &ledPinHandle, 2 * sync_data.timeout);

//        usleep(200000);
    }
}

void init_leds()
{
    /* Open LED pins */
    ledPinHandle = PIN_open(&ledPinState, pinTable);
    if (ledPinHandle == NULL)
    {
        while(1);
    }
}

void uart_writeCb (UART_Handle handle, void *buf, size_t count)
{

}

void init_uart()
{
    UART_Params uartParams;
    UART_Params_init(&uartParams);

    /* Open UART pins */
    UART_init();
    uartParams.readMode = UART_MODE_BLOCKING;
    uartParams.writeMode = UART_MODE_CALLBACK;
    uartParams.writeTimeout = UART_WAIT_FOREVER;
    uartParams.readTimeout = UART_WAIT_FOREVER;
    uartParams.readCallback = uart_writeCb;
    uartParams.writeCallback = uart_writeCb;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 500000;
    uartParams.dataLength = UART_LEN_8;
    uartParams.stopBits = UART_STOP_ONE;
    uartParams.parityType = UART_PAR_NONE;
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

void set_freq(uint16_t freq, uint16_t fractFreq)
{
    RF_cmdFs.frequency = freq;
    RF_cmdFs.fractFreq = fractFreq;
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);
}

//Select one of the following options for the different data rates
/*31.25Kbps*/
//#define DEV         (100)
//#define RATEWORD    (0x5000)
//#define RXBW        (0x53)
//#define FR_INT      (0x00)
//#define FR_FRC      (0xfb63)
/*62.5Kbps*/
//#define DEV         (100)
//#define RATEWORD    (0xa000)
//#define RXBW        (0x54)
//#define FR_INT      (0x00)
//#define FR_FRC      (0xfb63)
/*125Kbps*/
#define DEV         (340)
#define RATEWORD    (0x14000)
#define RXBW        (0x58)
#define FR_INT      (0x01)
#define FR_FRC      (0xd47a)
/*250Kbps*/
//#define DEV         (340)
//#define RATEWORD    (0x28000)
//#define RXBW        (0x5c)
//#define FR_INT      (0x01)
//#define FR_FRC      (0xd47a)

void init_radio()
{
    // Modulation & frequency Deviation
    RF_cmdPropRadioDivSetup.modulation.modType = 0;
    RF_cmdPropRadioDivSetup.modulation.deviation = DEV;
    RF_cmdPropRadioDivSetup.modulation.deviationStepSz = 0;
    RF_cmdPropRadioDivSetup.symbolRate.preScale = 0xF;
    RF_cmdPropRadioDivSetup.symbolRate.rateWord = RATEWORD;
    RF_cmdPropRadioDivSetup.rxBw = RXBW;
    RF_cmdPropRadioDivSetup.preamConf.nPreamBytes = 7;
    RF_cmdPropRadioDivSetup.preamConf.preamMode = 0;
    RF_cmdPropRadioDivSetup.formatConf.nSwBits = 24;
    RF_cmdPropRadioDivSetup.formatConf.bMsbFirst = 1;
    RF_cmdPropRadioDivSetup.formatConf.fecMode = 0;
    RF_cmdPropRadioDivSetup.formatConf.whitenMode = 6;
}

void get_helper_freq(uint16_t bs_freq, uint16_t bs_fractFreq, sync_params* sync_data)
{
    uint8_t freq_sep_int = FR_INT;
    uint16_t freq_sep_frac = FR_FRC;

    if (bs_fractFreq < freq_sep_frac)
    {
        sync_data->helper_freq = bs_freq - 900 - (freq_sep_int + 1);
        sync_data->helper_fractFreq = bs_fractFreq + (0xffff - freq_sep_frac);
    }
    else
    {
        sync_data->helper_freq = bs_freq - 900 - freq_sep_int;
        sync_data->helper_fractFreq = bs_fractFreq - freq_sep_frac;
    }
}
