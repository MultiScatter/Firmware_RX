/*
 * board.h
 *
 *  Created on: Nov 19, 2019
 *      Author: katanbaf
 */

#ifndef BOARD_H_
#define BOARD_H_

#include <ti/devices/cc13x2_cc26x2/driverlib/ioc.h>
#define REV_01

/***** Defines *****/
//#define RF_cmdFs RF_cmdFs_2gfsk200kbps154g_0
//#define RF_prop RF_prop_2gfsk200kbps154g_0
//#define RF_cmdPropRxAdv RF_cmdPropRxAdv_2gfsk200kbps154g_0
//#define RF_cmdPropRadioDivSetup RF_cmdPropRadioDivSetup_2gfsk200kbps154g_0

#ifdef REV_01
#define PIN_RLED        IOID_28
#define PIN_GLED        IOID_27
#else
#define PIN_RLED        IOID_19
#define PIN_GLED        IOID_18
#endif

#define PIN_ANT_SEL     IOID_6
#define PIN_BAND_SEL    IOID_7

#endif /* BOARD_H_ */
