/*
 * rx.h
 *
 *  Created on: Nov 19, 2019
 *      Author: katanbaf
 */

#ifndef RX_H_
#define RX_H_

void init_rxQueue();
void init_rx();
void get_pkts(RF_Handle* rfHandle, UART_Handle* uart, PIN_Handle* ledPinHandle, uint16_t timeout);
int32_t meas_interference(RF_Handle* rfHandle, uint8_t timeout, uint16_t readings, int16_t threshold);
//void get_pkts();


#endif /* RX_H_ */
