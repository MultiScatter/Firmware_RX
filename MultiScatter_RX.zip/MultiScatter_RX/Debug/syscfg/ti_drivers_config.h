/*
 *  ======== ti_drivers_config.h ========
 *  Configured TI-Drivers module declarations
 *
 *  The macros defines herein are intended for use by applications which
 *  directly include this header. These macros should NOT be hard coded or
 *  copied into library source code.
 *
 *  Symbols declared as const are intended for use with libraries.
 *  Library source code must extern the correct symbol--which is resolved
 *  when the application is linked.
 *
 *  DO NOT EDIT - This file is generated for the CC1312R1F3RGZ
 *  by the SysConfig tool.
 */
#ifndef ti_drivers_config_h
#define ti_drivers_config_h

#define CONFIG_SYSCONFIG_PREVIEW

#define CONFIG_CC1312R1F3RGZ
#ifndef DeviceFamily_CC13X2
#define DeviceFamily_CC13X2
#endif

#include <ti/devices/DeviceFamily.h>

#include <stdint.h>

/* support C++ sources */
#ifdef __cplusplus
extern "C" {
#endif


/*
 *  ======== CCFG ========
 */


/*
 *  ======== GPIO ========
 */

/* DIO18 */
extern const uint_least8_t              RLED_CONST;
#define RLED                            0
/* DIO19 */
extern const uint_least8_t              GLED_CONST;
#define GLED                            1
/* DIO6 */
extern const uint_least8_t              ANT_SEL_CONST;
#define ANT_SEL                         2
/* DIO7 */
extern const uint_least8_t              BAND_SEL_CONST;
#define BAND_SEL                        3
/* DIO28 */
extern const uint_least8_t              RLED_1_CONST;
#define RLED_1                          4
/* DIO27 */
extern const uint_least8_t              GLED_1_CONST;
#define GLED_1                          5
#define CONFIG_TI_DRIVERS_GPIO_COUNT    6

/* LEDs are active high */
#define CONFIG_GPIO_LED_ON  (1)
#define CONFIG_GPIO_LED_OFF (0)

#define CONFIG_LED_ON  (CONFIG_GPIO_LED_ON)
#define CONFIG_LED_OFF (CONFIG_GPIO_LED_OFF)


/*
 *  ======== PIN ========
 */
#include <ti/drivers/PIN.h>

extern const PIN_Config BoardGpioInitTable[];

/* Parent Signal: RLED GPIO Pin, (DIO18) */
#define CONFIG_PIN_5                   0x00000012
/* Parent Signal: GLED GPIO Pin, (DIO19) */
#define CONFIG_PIN_6                   0x00000013
/* Parent Signal: ANT_SEL GPIO Pin, (DIO6) */
#define CONFIG_PIN_2                   0x00000006
/* Parent Signal: BAND_SEL GPIO Pin, (DIO7) */
#define CONFIG_PIN_3                   0x00000007
/* Parent Signal: RLED_1 GPIO Pin, (DIO28) */
#define CONFIG_PIN_4                   0x0000001c
/* Parent Signal: GLED_1 GPIO Pin, (DIO27) */
#define CONFIG_PIN_7                   0x0000001b
/* Parent Signal: CONFIG_UART_0 TX, (DIO12) */
#define CONFIG_PIN_0                   0x0000000c
/* Parent Signal: CONFIG_UART_0 RX, (DIO13) */
#define CONFIG_PIN_1                   0x0000000d
#define CONFIG_TI_DRIVERS_PIN_COUNT    8




/*
 *  ======== UART ========
 */

/*
 *  TX: DIO12
 *  RX: DIO13
 */
extern const uint_least8_t              CONFIG_UART_0_CONST;
#define CONFIG_UART_0                   0
#define CONFIG_TI_DRIVERS_UART_COUNT    1


/*
 *  ======== Board_init ========
 *  Perform all required TI-Drivers initialization
 *
 *  This function should be called once at a point before any use of
 *  TI-Drivers.
 */
extern void Board_init(void);

/*
 *  ======== Board_initGeneral ========
 *  (deprecated)
 *
 *  Board_initGeneral() is defined purely for backward compatibility.
 *
 *  All new code should use Board_init() to do any required TI-Drivers
 *  initialization _and_ use <Driver>_init() for only where specific drivers
 *  are explicitly referenced by the application.  <Driver>_init() functions
 *  are idempotent.
 */
#define Board_initGeneral Board_init

#ifdef __cplusplus
}
#endif

#endif /* include guard */
