/*
 * tx.c
 *
 *  Created on: Nov 21, 2019
 *      Author: katanbaf
 */




/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include <ti_radio_config.h>
#include "tx.h"

/***** Defines *****/
#define SYNC_PAYLOAD_LENGTH 10
/***** Prototypes *****/

/***** Variable declarations *****/
static uint8_t syncPkt[SYNC_PAYLOAD_LENGTH];

void init_tx()
{
    /* Initialize TX_ADV command from TX command */
    RF_cmdPropTx.pktLen = SYNC_PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = syncPkt;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;
    RF_cmdPropTx.syncWord = 0x0055904E;
}

void send_sync_pkt(RF_Handle* rfHandle, sync_params data)
{
    syncPkt[0] = (uint8_t)(data.tx_id);
    syncPkt[1] = (uint8_t)(data.tag_id);
    syncPkt[2] = (uint8_t)data.helper_freq;
    syncPkt[3] = (uint8_t)(data.helper_fractFreq >> 8);
    syncPkt[4] = (uint8_t)data.helper_fractFreq;
    syncPkt[5] = (uint8_t)data.tag_cmd;
    syncPkt[6] = (uint8_t)data.timeout;
    syncPkt[7] = (uint8_t)(((data.power & 0x3f) << 2) | ((data.wake_up & 0x01) << 1) | ((data.tx_ant & 0x01)));
    syncPkt[8] = (uint8_t)(data.ver_seq >> 8);
    syncPkt[9] = (uint8_t)(data.ver_seq);

    RF_EventMask terminationReason = RF_runCmd(*rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, NULL, 0);

}

