/*
 * tx.h
 *
 *  Created on: Nov 21, 2019
 *      Author: katanbaf
 */

#ifndef TX_H_
#define TX_H_

#define VER_SEQ (0xabf2)
typedef struct sync_params
{
    uint16_t ver_seq;
    uint8_t helper_freq;
    uint16_t helper_fractFreq;
    uint8_t tx_id;
    uint8_t tag_id;
    uint8_t timeout;
    uint8_t tag_cmd;
    uint8_t power;
    uint8_t wake_up;
    uint8_t tag_ant;
    uint8_t tx_ant;
    uint8_t rx_ant;
}sync_params;

void init_tx();
void send_sync_pkt(RF_Handle* rfHandle, sync_params data);

#endif /* TX_H_ */
